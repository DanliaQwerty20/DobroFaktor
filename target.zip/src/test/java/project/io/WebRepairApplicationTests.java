package project.io;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebRepairApplicationTests {

	@Test
	void contextLoads() {
	}

}
